const style = document.createElement('style');
style.textContent = `
/* Cole seu CSS aqui como string */

body {
  --yt-spec-base-background: rgba(93, 10, 151, .02);
}

html[darker-dark-theme][dark], [darker-dark-theme] [dark] {
    --yt-spec-text-primary: #8a0fc6e0;
}

canvas, caption, center, cite, code, dd, del, dfn, div, dl, dt, em, embed, fieldset, font, form, h1, h2, h3, h4, h5, h6, hr, i, iframe, img, ins, kbd, label, legend, li, menu, object, ol, p, pre, q, s, samp, small, span, strike, strong, sub, sup, table, tbody, td, tfoot, th, thead, tr, tt, u, ul, var {
    color: blueviolet;
}

.ytSearchboxComponentHost {
    color: #8a0fc6e0;
}

html, html[dark], [dark], html, [light] {
    --yt-spec-base-background: rgba(93, 10, 151, .02);
    --yt-spec-text-primary: #8a0fc6e0;
    --yt-live-chat-primary-text-color: #cb84fff0;
    --yt-live-chat-secondary-text-color: #7e2ea4e0;
    --yt-spec-text-secondary: #4e0b6fe0;
    --yt-spec-badge-chip-background: #57188626;
    --yt-spec-10-percent-layer: #8a0fc6e0;
    --yt-spec-static-ad-yellow: #de9affe0;
}

.ytSearchboxComponentInputBox {
    border-color: #8a0fc6e0;
}

.yt-spec-button-shape-next--call-to-action.yt-spec-button-shape-next--filled {
    background: #292929e0;
}

#progress.ytd-thumbnail-overlay-resume-playback-renderer {
    background: linear-gradient(to right,#a244ff 80%,#5a00b9 100%);
}

.ytp-swatch-background-color {
    background-color: #8a0fc6e0;
}

.ytp-time-current, .ytp-time-separator, .ytp-time-duration {
    color: #8a0fc6e0;
}

.yt-icon.yt-live-chat-ticker-renderer {
    background-color: #8a0fc6e0;
}

.ytVideoMetadataCarouselViewModelHost {
    background-color: #57188626;
}
}

`;
document.head.appendChild(style);
